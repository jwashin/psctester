import unittest
import sys
import cgitb

import pytest


class TestCgitb(unittest.TestCase):

    def test_fonts(self):
        text = "Hello Robbie!"
        self.assertEqual(cgitb.small(text), "<small>{}</small>".format(text))
        self.assertEqual(cgitb.strong(text), "<strong>{}</strong>".format(text))
        self.assertEqual(cgitb.grey(text),
                         '<font color="#909090">{}</font>'.format(text))

    def test_blanks(self):
        self.assertEqual(cgitb.small(""), "")
        self.assertEqual(cgitb.strong(""), "")
        self.assertEqual(cgitb.grey(""), "")

    def test_html(self):
        try:
            raise ValueError("Hello World")
        except ValueError as err:
            # If the html was templated we could do a bit more here.
            # At least check that we get details on what we just raised.
            html = cgitb.html(sys.exc_info())
            self.assertIn("ValueError", html)
            self.assertIn(str(err), html)

    def test_text(self):
        try:
            raise ValueError("Hello World")
        except ValueError:
            text = cgitb.text(sys.exc_info())
            self.assertIn("ValueError", text)
            self.assertIn("Hello World", text)


def test_syshook_no_logdir_default_format(tmp_path, capsys):
    cgitb.enable(logdir=tmp_path)
    try:
        raise ValueError("Hello World")
    except ValueError:
        sys.excepthook(*sys.exc_info())
    captured = capsys.readouterr()
    assert "ValueError" in captured.out
    assert "Hello World" in captured.out
    assert "<strong>test_syshook_no_logdir_default_format</strong>" in captured.out
    # By default we emit HTML markup.
    assert "<p>" in captured.out
    assert "</p>" in captured.out


def test_syshook_no_logdir_text_format(tmp_path, capsys):
    # Issue 12890: we were emitting the <p> tag in text mode.
    cgitb.enable(format="text", logdir=tmp_path)
    try:
        raise ValueError("Hello World")
    except ValueError:
        sys.excepthook(*sys.exc_info())
    captured = capsys.readouterr()
    assert "ValueError" in captured.out
    assert "Hello World" in captured.out
    assert "<p>" not in captured.out
    assert "</p>" not in captured.out
