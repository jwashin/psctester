tester_number = 666                         # ID number of the PSC tester
ST4_serno_list = [25836, 25843, 10002]      # List of serial numbers of possible ST4s

